# coding=gbk
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
import random
import torch
import os


# seed=1,20, 42,3407,
def set_seed(seed=1):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.enabled = False


set_seed(seed=42)
from sklearn.preprocessing import StandardScaler

# def data_split(test_size=0.1):
data_frame = pd.read_csv(r'./Chengdu_housing.csv')
all_data = np.array(data_frame)


def normal(x, min_val=0):
    x_min = np.min(x)
    x_max = np.max(x)
    x_mean = np.mean(x)
    x_std = np.std(x) + 1e-8
    if x_min == 0 and x_max == 0:
        return x
    if min_val == -1:
        x_norm = 2 * ((x - x_min) / (x_max - x_min)) - 1
    if min_val == 0:
        # scaler=StandardScaler()
        # x_norm = scaler.fit_transform(x)
        # x_norm = ((x - x_min) / (x_max - x_min))
        x_norm = (x - x_mean) / x_std
    return x_norm


for i in range(1, all_data.shape[1]-1):
    all_data[:, i] = normal(all_data[:, i], min_val=0)

for i in range(10):
    train_data, valid_data = train_test_split(all_data, test_size=0.9)
    train_data = pd.DataFrame(train_data)
    valid_data = pd.DataFrame(valid_data)
    print(len(train_data), len(valid_data))
    train_data.to_csv('./data/train{}.csv'.format(i), index=False)
    valid_data.to_csv('./data/valid{}.csv'.format(i), index=False)
