# -*- coding : utf-8 -*-

from dataloader_anp import DatasetGP, DatasetGP_test, data_load
from model_anp import SpatialNeuralProcess, Criterion
import torch as torch
import torch.optim as optim
from torch.utils.data import DataLoader

from matplotlib import pyplot as plt

import numpy as np
import os
import pandas as pd
from train_configs import train_runner, val_runner
from math import sqrt

import random
import time

start = time.perf_counter()
time.sleep(2)


# torch.cuda.manual_seed_all(seed=42)

def set_seed(seed=42):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.enabled = False


def adjust_learning_rate(optimizer, start_lr, step_num, warmup_step=10):
    # lr = start_lr * warmup_step ** 0.5 * min(step_num * warmup_step ** -1.5, step_num ** -0.5)
    if step_num <= 100:
        lr = start_lr
    elif 100 < step_num <= 200:
        lr = start_lr * 0.5
    # # elif 500 < step_num <=1000:
    # #     lr = start_lr * 0.01
    else:
        lr = start_lr * 0.1
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr
    return lr


def main():
    set_seed(42)
    n_epoches = 300
    n_tasks = 30
    batch_size = 1
    x_size = 9
    y_size = 1
    start_lr = 0.001
    num_hidden = 128
    num_context = n_epoches
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    for xuhao in range(10):
        trainset = DatasetGP(n_tasks=n_tasks, xuhao=xuhao, batch_size=batch_size)
        testset = DatasetGP_test(n_tasks=n_tasks, xuhao=xuhao, batch_size=batch_size)
        model = SpatialNeuralProcess(x_size=x_size, y_size=y_size, num_hidden=num_hidden).to(device)
        criterion = Criterion()
        optimizer = optim.Adam(model.parameters(), lr=start_lr)

        model.train()
        epoch_train_loss = []
        epoch_valid_loss = []
        lo = np.inf

        for epoch in range(n_epoches):
            trainloader = DataLoader(trainset, shuffle=True)
            testloader = DataLoader(testset, batch_size=1, shuffle=True)
            # adjust_learning_rate(optimizer, start_lr,epoch+1)

            SpatialNeuralProcess.training = True
            mean_y, var_y, target_id, target_y, context_id, loss, train_mse = train_runner(
                model, trainloader, criterion, optimizer)

            SpatialNeuralProcess.training = True
            val_pred_y, val_var_y, val_target_id, val_target_y, val_loss, valid_mse = val_runner(
                model, testloader, criterion)


            if lo >= val_loss:
                lo = val_loss
                train_mse = (torch.sum((target_y - mean_y) ** 2)) / len(target_y)
                train_rmse = sqrt(train_mse)
                train_mae = (torch.sum(torch.absolute(target_y - mean_y))) / len(target_y)
                train_r2 = 1 - ((torch.sum((target_y - mean_y) ** 2)) / torch.sum(
                    (target_y - target_y.mean()) ** 2))
                valid_mse = (torch.sum((val_target_y - val_pred_y) ** 2)) / len(val_target_y)
                valid_rmse = sqrt(valid_mse)
                valid_mae = (torch.sum(torch.absolute(val_target_y - val_pred_y))) / len(val_target_y)

                valid_r2 = 1 - ((torch.sum((val_target_y - val_pred_y) ** 2)) / torch.sum(
                    (val_target_y - val_target_y.mean()) ** 2))

                print(
                    "ID: {} \t Train Epoch: {} \t Lr:{:.4f},train loss: {:.4f},train_mae: {:.4f},train_mse: {:.4f}, train_rmse: {:.4f},train_r2: {:.4f}".format(
                        xuhao, epoch + 1, optimizer.state_dict()['param_groups'][0]['lr'], loss, train_mae, train_mse, train_rmse, train_r2))
                print(
                    "ID: {} \t Valid Epoch: {} \t Lr:{:.4f},valid loss: {:.4f},valid_mae: {:.4f},valid_mse: {:.4f}, valid_rmse: {:.4f},valid_r2: {:.4f}".format(
                        xuhao, epoch + 1, optimizer.state_dict()['param_groups'][0]['lr'], val_loss, valid_mae, valid_mse, valid_rmse, valid_r2))
                torch.save({'model': model.state_dict(),
                            'optimizer': optimizer.state_dict()},
                           os.path.join('checkpoint_anp', 'checkpoint_%d.pth.tar' % (xuhao)))
            if epoch % 50 == 0:
                print(
                    "ID: {} \t Train Epoch: {} \t Lr:{:.4f},train loss: {:.4f},train_mse: {:.4f}".format(
                        xuhao, epoch, optimizer.state_dict()['param_groups'][0]['lr'], loss, train_mse))
                print(
                    "ID: {} \t Valid Epoch: {} \t Lr:{:.4f},valid loss: {:.4f},valid_mse: {:.4f}".format(
                        xuhao, epoch, optimizer.state_dict()['param_groups'][0]['lr'], val_loss, valid_mse))

            epoch_train_loss.append(loss)
            epoch_valid_loss.append(val_loss)

        end = time.perf_counter()
        print(str(end - start))
        # epoch loss
        fig = plt.gcf()
        fig.set_size_inches(10, 5)
        plt.xlabel('Epochs', fontsize=15)
        plt.ylabel('Loss', fontsize=15)
        epoch = np.linspace(1, n_epoches, n_epoches)
        plt.plot(epoch, epoch_train_loss, 'blue', label='Train loss')
        plt.plot(epoch, epoch_valid_loss, 'r', label='Valid loss')
        plt.grid(True)
        plt.legend()
        plt.savefig('./figure_anp/loss.jpg'.format(xuhao))
        # plt.show()
        plt.close()
        loss_value = pd.DataFrame({'epoch_train_loss': epoch_train_loss, 'epoch_valid_loss': epoch_valid_loss})
        loss_value.to_csv('./figure_anp/loss_{}.csv'.format(xuhao), index=False)

        c = np.linspace(0, len(val_target_y), len(val_target_y))
        plt.scatter(c, val_target_y.detach().cpu().numpy(), color="b", marker="x", label="true_value", vmin=0, vmax=50)
        plt.scatter(c, val_pred_y.detach().cpu().numpy(), color="r", marker="o", label="predict_value", vmin=0, vmax=50)
        plt.fill_between(c, (val_pred_y - val_var_y).detach().cpu().numpy(), (val_pred_y + val_var_y).detach().cpu().numpy(), alpha=0.2, facecolor="r",
                         interpolate=True)
        plt.legend()
        plt.xlabel('Well-ID')
        plt.ylabel('Reservoir thickness')
        plt.savefig('./figure_anp/predict_{}_{}.jpg'.format(num_context, xuhao), bbox_inches='tight')
        plt.grid()
        plt.close()

        prediction = pd.DataFrame(
            {"id_val": val_target_id.detach().cpu().numpy(), "pred": val_target_y.detach().cpu().numpy(), "val_pred": val_pred_y.detach().cpu().numpy(),
             "cha": val_target_y.detach().cpu().numpy() - val_pred_y.detach().cpu().numpy(), 'val_var_y': val_var_y.detach().cpu().numpy(), })
        prediction.to_csv('./prediction/prediction_{}.csv'.format(xuhao), index=False)

    end = time.perf_counter()
    print(str(end - start))


if __name__ == "__main__":
    main()
