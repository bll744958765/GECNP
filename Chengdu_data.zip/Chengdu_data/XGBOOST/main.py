import xgboost as xgb
from xgboost import XGBRegressor
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_absolute_percentage_error
from sklearn.metrics import r2_score
import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings("ignore")
param_grid = {
    'n_estimators': [10, 20, 30, 40, 50, 100, 200, 300],
    'max_depth': [2, 4, 6, 8, 10],
    'learning_rate': [0.001, 0.005, 0.01, 0.05, 0.1, 0.5],
    'subsample': [0.5, 0.8, 1.0],
    'colsample_bytree': [0.5, 0.8, 1.0]
}


def normal(x, min_val=0):
    x_min = np.min(x)
    x_max = np.max(x)
    x_mean = np.mean(x)
    x_std = np.std(x) + 1e-8
    if x_min == 0 and x_max == 0:
        return x
    if min_val == -1:
        x_norm = 2 * ((x - x_min) / (x_max - x_min)) - 1
    if min_val == 0:
        # scaler=StandardScaler()
        # x_norm = scaler.fit_transform(x)
        # x_norm = ((x - x_min) / (x_max - x_min))
        x_norm = (x - x_mean) / x_std
    return x_norm


data_frame = pd.read_csv(r'./Chengdu_housing.csv')

all_data = np.array(data_frame)
x = all_data[:, 1:-1]
y = all_data[:, -1]
for i in range(x.shape[1]):
    x[:, i] = normal(x[:, i], min_val=0)

list0 = []
list1 = []
xgb_model = XGBRegressor(objective='reg:squarederror', random_state=42)
for i in range(10):
    # 数据集拆分features
    X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.9, random_state=i)
    # _, X_test, _, y_test = train_test_split(X_test, y_test, test_size=0.78, random_state=i)
    # 创建XGBRegressor对象
    # xgb_model = XGBRegressor(objective='reg:squarederror', colsample_bytree=0.3, learning_rate=0.01,
    #                          max_depth=10, alpha=15, n_estimators=20)
    #

    grid_model = GridSearchCV(
        estimator=xgb_model,
        param_grid=param_grid,
        scoring='neg_mean_absolute_error',
        cv=5,
        verbose=1,
        n_jobs=-1
    )

    # 训练模型
    grid_model.fit(X_train, y_train)

    # 预测
    y_pred = grid_model.predict(X_test)

    # 评估模型
    valid_mse = mean_squared_error(y_test, y_pred)
    valid_mae = mean_absolute_error(y_test, y_pred)
    valid_rmse = np.sqrt(valid_mse)
    valid_mape = mean_absolute_percentage_error(y_test, y_pred)
    valid_r2 = r2_score(y_test, y_pred)

    list0 = [round(valid_mae, 4), round(valid_mse, 4), round(valid_rmse, 4), round(valid_mape, 4), round(valid_r2, 4), ]
    list1.append(list0)
    print("complete{}".format(i))
    with open("./train_notes.txt", 'a+') as f:
        # Include any experiment notes here:
        f.write("{}-th training  mae, mse, rmse, mape, r2, \n".format(i))
        f.write("{:.4f}, {:.4f}, {:.4f},{:.4f}, {:.4f}， \n"
                .format(valid_mae,valid_mse,valid_rmse,valid_mape,valid_r2))

print(np.mean(list1, axis=0))
print(np.std(list1, axis=0))

with open("./train_notes.txt", 'a+') as f:
    # Include any experiment notes here:
    f.write("final  mae, mse, rmse, mape, r2, \n")
    f.write("mean: {}\n std: {} \n".format(np.mean(list1, axis=0), np.std(list1, axis=0)))