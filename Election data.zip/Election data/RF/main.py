import xgboost as xgb
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import mean_absolute_error, mean_squared_error,mean_absolute_percentage_error, r2_score

import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings("ignore")


def normal(x, min_val=0):
    x_min = np.min(x)
    x_max = np.max(x)
    x_mean = np.mean(x)
    x_std = np.std(x) + 1e-8
    if x_min == 0 and x_max == 0:
        return x
    if min_val == -1:
        x_norm = 2 * ((x - x_min) / (x_max - x_min)) - 1
    if min_val == 0:
        # scaler=StandardScaler()
        # x_norm = scaler.fit_transform(x)
        # x_norm = ((x - x_min) / (x_max - x_min))
        x_norm = (x - x_mean) / x_std
    return x_norm


data_frame = pd.read_csv(r'./election result.csv')

all_data = np.array(data_frame)
x = all_data[:, 1:-1]
y = all_data[:, -1]
for i in range(x.shape[1]):
    x[:, i] = normal(x[:, i], min_val=0)

rf = RandomForestRegressor(random_state=42)

param_grid = {
    'n_estimators': [10,50, 100,150, 200],
    'max_depth': [5, 10, 15,20],
    'min_samples_split': [2, 5,10],
    'min_samples_leaf': [1, 2,5]
}

grid_search = GridSearchCV(
    estimator=rf,
    param_grid=param_grid,
    cv=5,
    n_jobs=-1,
    verbose=1,
    scoring='neg_mean_absolute_error'
)


list0 = []
list1 = []

for i in range(10):
    # 数据集拆分features
    X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.9, random_state=i)
    # _, X_test, _, y_test = train_test_split(X_test, y_test, test_size=0.78, random_state=i)
    # ------------------ 5. 模型训练与超参数搜索 ------------------
    grid_search.fit(X_train, y_train)
    best_model = grid_search.best_estimator_

    print("\nBest Parameters:", grid_search.best_params_)

    # ------------------ 6. 模型预测与评估 ------------------
    y_pred = best_model.predict(X_test)

    # 评估模型
    valid_mse = mean_squared_error(y_test, y_pred)
    valid_mae = mean_absolute_error(y_test, y_pred)
    valid_rmse = np.sqrt(valid_mse)
    valid_mape = mean_absolute_percentage_error(y_test, y_pred)
    valid_r2 = r2_score(y_test, y_pred)

    list0 = [round(valid_mae, 4), round(valid_mse, 4), round(valid_rmse, 4), round(valid_mape, 4), round(valid_r2, 4), ]
    list1.append(list0)
    print("complete{}".format(i))
    with open("./train_notes.txt", 'a+') as f:
        # Include any experiment notes here:
        f.write("{}-th training  mae, mse, rmse, mape, r2, \n".format(i))
        f.write("{:.4f}, {:.4f}, {:.4f},{:.4f}, {:.4f}， \n"
                .format(valid_mae,valid_mse,valid_rmse,valid_mape,valid_r2))

print(np.mean(list1, axis=0))
print(np.std(list1, axis=0))

with open("./train_notes.txt", 'a+') as f:
    # Include any experiment notes here:
    f.write("final  mae, mse, rmse, mape, r2, \n")
    f.write("mean: {}\n std: {} \n".format(np.mean(list1, axis=0), np.std(list1, axis=0)))