import torchvision
# -*- coding : utf-8 -*-
import pandas as pd
from dataloader_anp import DatasetGP_test,data_load
from model_anp import SpatialNeuralProcess, Criterion

import torch as torch
from train_configs import val_runner
from torch.utils.data import DataLoader
from matplotlib import pyplot as plt
import numpy as np


device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

n_tasks = 1
batch_size = 1
x_size = 13
y_size = 1
z_size = 128
lr = 0.001
# num_context =709
num_hidden = 128
list1 = []
list = []
model = SpatialNeuralProcess(x_size=x_size, y_size=y_size, num_hidden=num_hidden).to(device)

for xuhao in range(10):
    dataset = DatasetGP_test(n_tasks=n_tasks, xuhao=xuhao, batch_size=batch_size)
    testloader = DataLoader(dataset, batch_size=1, shuffle=False)

    state_dict = torch.load('./checkpoint_anp/checkpoint_{}.pth.tar'.format(xuhao))
    model.load_state_dict(state_dict=state_dict['model'])
    model.eval()
    criterion = Criterion()


    val_pred_y, val_var_y, val_target_id, val_target_y, val_loss, kl_loss,valid_mse = val_runner(model, testloader, criterion)

    valid_mse = (torch.sum((val_target_y - val_pred_y) ** 2)) / len(val_target_y)
    valid_rmse = torch.sqrt(valid_mse)
    valid_mae = (torch.sum(torch.absolute(val_target_y - val_pred_y))) / len(val_target_y)
    valid_r2 = 1 - ((torch.sum((val_target_y - val_pred_y) ** 2)) / torch.sum((val_target_y - val_target_y.mean()) ** 2))


    val_target_y = val_target_y.cpu().detach().numpy()
    val_pred_y = val_pred_y.cpu().detach().numpy()
    val_var_y = val_var_y.cpu().detach().numpy()
    val_target_id = val_target_id.cpu().detach().numpy()

    valid_mse = (np.sum((val_target_y - val_pred_y) ** 2)) / len(val_target_y)
    valid_rmse = np.sqrt(valid_mse)
    valid_mae = (np.sum(np.absolute(val_target_y - val_pred_y))) / len(val_target_y)
    corr = np.corrcoef(val_target_y, val_pred_y)
    # print(corr[0,1])
    C = (2 * corr[0, 1] * np.std(val_pred_y) * np.std(val_target_y)) / (np.var(val_target_y) + np.var(val_pred_y) + (val_target_y.mean() - val_pred_y.mean()) ** 2)

    # plt figure
    c = np.linspace(0, len(val_target_y), len(val_target_y))
    plt.scatter(c, val_target_y, color="b", marker="x", label="true_value")
    plt.scatter(c, val_pred_y, color="r", marker="o", label="predict_value")
    plt.fill_between(c, val_pred_y - val_var_y, val_pred_y + val_var_y, alpha=0.2, facecolor="r", interpolate=True)
    # plt.xticks(ID)
    plt.legend()
    plt.xlabel('Well-ID')
    plt.ylabel('Reservoir thickness')
    plt.savefig('./figure_anp/predict_{}.jpg'.format(xuhao), bbox_inches='tight')
    plt.grid()
    plt.close()

    prediction = pd.DataFrame(
        {"id": np.array(val_target_id), "true": np.array(val_target_y), "pred": np.array(val_pred_y),
         "cha": np.array(val_target_y) - np.array(val_pred_y), 'var_y': np.array(val_var_y)})
    prediction.to_csv('./prediction/prediction_val_{}.csv'.format(xuhao), index=False)
    loss= val_loss - kl_loss
    print("ID:", xuhao, "valid_MAE:", round(valid_mae, 4), "valid_MSE:", round(valid_mse, 4), " valid_RMSE:", round(valid_rmse, 4),
          " valid_R-square:", round(valid_r2.item(), 4), "CCC:", round(C, 4), "average_var:", round(np.mean(val_var_y), 4),'log_like',loss)

    list = [round(valid_mae, 4),round(valid_mse, 4), round(valid_rmse, 4), round(valid_r2.item(), 4), round(C, 4), round(np.mean(val_var_y), 4),loss]
    list1.append(list)



# print('list:', list1)
print(np.mean(list1, axis=0))
print(np.std(list1, axis=0))