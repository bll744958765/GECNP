from pykrige.ok import OrdinaryKriging
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error, mean_absolute_percentage_error, r2_score
import numpy as np
import pandas as pd
import itertools
import warnings

warnings.filterwarnings("ignore")


def normal(x, min_val=0):
    x_min = np.min(x)
    x_max = np.max(x)
    x_mean = np.mean(x)
    x_std = np.std(x) + 1e-8
    if x_min == 0 and x_max == 0:
        return x
    if min_val == -1:
        x_norm = 2 * ((x - x_min) / (x_max - x_min)) - 1
    if min_val == 0:
        # scaler=StandardScaler()
        # x_norm = scaler.fit_transform(x)
        # x_norm = ((x - x_min) / (x_max - x_min))
        x_norm = (x - x_mean) / x_std
    return x_norm


data_frame = pd.read_csv(r'./election result.csv')

all_data = np.array(data_frame)
x = all_data[:, 3:-1]
y = all_data[:, -1]
coords = all_data[:, 1:3]
for i in range(x.shape[1]):
    x[:, i] = normal(x[:, i], min_val=0)
for i in range(coords.shape[1]):
    coords[:, i] = normal(coords[:, i], min_val=0)


# 分段预测函数
def batch_execute(OK, lon_test, lat_test, batch_size=500):
    n = len(lon_test)
    kriged_preds = []
    kriged_vars = []
    for i in range(0, n, batch_size):
        end = min(i + batch_size, n)
        batch_lon = lon_test[i:end]
        batch_lat = lat_test[i:end]
        preds, vars = OK.execute('points', batch_lon, batch_lat)
        kriged_preds.append(preds)
        kriged_vars.append(vars)
    return np.concatenate(kriged_preds),np.concatenate(kriged_vars)


list0 = []
list1 = []
t = 2000
for xuhao in range(10):
    # 数据集拆分features
    X_train, X_test, y_train, y_test, coord_train, coord_test = train_test_split(
        x, y, coords, test_size=0.9, random_state=xuhao)

    # 拟合趋势模型
    reg = LinearRegression().fit(X_train, y_train)
    residuals = y_train - reg.predict(X_train)

    lon_train, lat_train = coord_train[:, 0], coord_train[:, 1]
    lon_test, lat_test = coord_test[:, 0], coord_test[:, 1]

    # 网格参数空间
    variogram_models = ['linear', 'power', 'gaussian', 'spherical', 'exponential']
    ranges = [0.1, 1.0, 10.0]
    sills = [0.1, 1.0, 10.0]
    nuggets = [0.0, 0.01, 0.1]

    param_grid = list(itertools.product(variogram_models, ranges, sills, nuggets))

    best_mse = float('inf')
    best_params = None

    # 网格搜索
    print("Starting grid search over OrdinaryKriging parameters...")

    for i, (model, range_, sill, nugget) in enumerate(param_grid):
        try:
            OK = OrdinaryKriging(
                lon_train, lat_train, residuals,
                variogram_model=model,
                variogram_parameters={'range': range_, 'sill': sill, 'nugget': nugget},
                verbose=False,
                enable_plotting=False
            )
            kriged_residuals,kriged_residuals_vars = batch_execute(OK, lon_test, lat_test, batch_size=t)
            trend_pred = reg.predict(X_test)
            y_pred = trend_pred + kriged_residuals
            mse = mean_squared_error(y_test, y_pred)

            if mse < best_mse:
                best_mse = mse
                best_params = (model, range_, sill, nugget)
            print(f"[{i + 1}/{len(param_grid)}] model={model}, range={range_}, sill={sill}, nugget={nugget}, MSE={mse:.4f}")
        except Exception as e:
            print(f"Error with params: model={model}, range={range_}, sill={sill}, nugget={nugget}, error={e}")

    # print("\nBest Parameters:")
    # print(f"variogram_model = {best_params[0]}")
    # print(f"range = {best_params[1]}, sill = {best_params[2]}, nugget = {best_params[3]}")
    # print(f"Best MSE: {best_mse:.4f}")

    # 评估模型
    valid_mse = mean_squared_error(y_test, y_pred)
    valid_mae = mean_absolute_error(y_test, y_pred)
    valid_rmse = np.sqrt(valid_mse)
    valid_mape = mean_absolute_percentage_error(y_test, y_pred)
    valid_r2 = r2_score(y_test, y_pred)
    avg_variance = np.mean(kriged_residuals_vars)

    # 负对数似然（Negative Log Likelihood）
    nll = 0.5 * np.mean(np.log(2 * np.pi * kriged_residuals_vars + 1e-6) + (y_test - y_pred) ** 2 / (kriged_residuals_vars + 1e-6))

    list0 = [round(valid_mae, 4), round(valid_mse, 4), round(valid_rmse, 4), round(valid_mape, 4), round(valid_r2, 4), round(avg_variance, 4),round(nll, 4)]
    list1.append(list0)
    print("complete{}".format(i))
    with open("./train_notes.txt", 'a+') as f:
        # Include any experiment notes here:
        f.write("{}-th training  mae, mse, rmse, mape, r2, avg_variance,nll \n".format(xuhao))
        f.write("{:.4f}, {:.4f}, {:.4f},{:.4f}, {:.4f},{:.4f},{:.4f} \n"
                .format(valid_mae, valid_mse, valid_rmse, valid_mape, valid_r2, avg_variance, nll))

print(np.mean(list1, axis=0))
print(np.std(list1, axis=0))

with open("./train_notes.txt", 'a+') as f:
    # Include any experiment notes here:
    f.write("final  mae, mse, rmse, mape, r2, \n")
    f.write("mean: {}\n std: {} \n".format(np.mean(list1, axis=0), np.std(list1, axis=0)))
