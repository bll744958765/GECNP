# -*- coding : utf-8 -*-

"""
实现spatial Neural Process
"""
from attention import *
import torch
import torch.nn as nn


# class LocationEncoder(nn.Module):
#     """
#     Location Encoder [w]
#     """
#
#     def __init__(self, num_hidden):
#         super(LocationEncoder, self).__init__()
#         self.input_projection = Linear(3, num_hidden)
#         self.context_projection = Linear(2, num_hidden)
#         self.target_projection = Linear(num_hidden, num_hidden)
#         self.cross_attentions = nn.ModuleList([Attention(num_hidden) for _ in range(2)])
#         self.self_attentions = nn.ModuleList([Attention(num_hidden) for _ in range(1)])
#
#
#     def forward(self, context_x, context_y, target_x):
#         encoder_input = torch.cat([context_x, context_y],
#                                   dim=-1)  # concat context location (x), context value (y)
#         encoder_input = self.input_projection(encoder_input)  # (bs,nc,13)--> (bs,nc,num_hidden)
#
#         # self attention layer
#         for attention in self.self_attentions:
#             encoder_input, _ = attention(encoder_input, encoder_input, encoder_input)
#         value = encoder_input
#         key = self.context_projection(context_x[..., 0:2])  # (bs,nc,num_hidden)
#         query = self.context_projection(target_x[..., 0:2])  # (bs,nt,num_hidden)
#
#         for attention in self.cross_attentions:  # cross attention layer
#             rep, _ = attention(key, value, query)  # (bs,nt,hidden_number)
#
#         return rep


class DeterministicEncoder(nn.Module):
    """
    Deterministic Encoder [r]
    """

    def __init__(self, input_dim, num_hidden):
        super(DeterministicEncoder, self).__init__()

        self.self_attentions = nn.ModuleList([Attention(num_hidden) for _ in range(2)])
        self.cross_attentions = nn.ModuleList([Attention(num_hidden) for _ in range(2)])
        self.target_projection = Linear(input_dim-1, num_hidden)
        self.context_projection = Linear(input_dim - 1, num_hidden)
        self.input_projection = Linear(input_dim, num_hidden)
        self.linear = nn.Linear(num_hidden, 2)
        self.softplus=nn.Softplus()


    def forward(self, context_x, context_y, target_x):
        _, nt, x_size = target_x.shape
        encoder_input = torch.cat([context_x, context_y],
                                  dim=-1)  # concat context location (x), context value (y)

        encoder_input = self.input_projection(encoder_input)  # (bs,nc,13)--> (bs,nc,num_hidden)

        # # self attention layer
        # for attention in self.self_attentions:
        #     encoder_input, _ = attention(encoder_input, encoder_input, encoder_input)
        #
        # query = self.target_projection(target_x)  # (bs,nt,12)--> (bs,nt,num_hidden)
        # keys = self.context_projection(context_x)  # (bs,nc,12)--> (bs,nc,num_hidden)
        # for attention in self.cross_attentions:  # cross attention layer
        #     query, _ = attention(keys, encoder_input, query)  # (bs,nt,hidden_number)

        # encoder = torch.mean(query, dim=1)  # (bs, 1,num_hidden)

        encoder = torch.mean(encoder_input, dim=1)  # (bs, 1,num_hidden)
        encoder = encoder.unsqueeze(dim=1).repeat((1, nt, 1))  # (bs, num_hidden)
        out = self.linear(encoder)  # decoder cat(z,target_x, r, w)  (bs,3*num_hidden+tx)--> (bs  nt, 2)
        mu = out[:, :, 0]  # mean
        log_sigma = out[:, :, 1]
        sigma = 0.1 + 0.9 * self.softplus(log_sigma)  # variance  sigma=0.1+0.9*log(1+exp(log_sigma))
        std = sigma.sqrt().cuda(0)
        eps = torch.FloatTensor(std.size()).normal_().cuda(0)  # 随机张量方法normal_()，完成高斯空间的采样过程。
        sample = eps.mul(std).add_(mu)
        return mu, sigma, sample


# class LatentEncoder(nn.Module):
#     """
#     Latent Encoder [z]
#     """
#
#     def __init__(self, x_size, y_size, num_hidden):
#         super(LatentEncoder, self).__init__()
#         self.x_size = x_size
#         self.y_size = y_size
#         self.num_hidden = num_hidden
#         self.input_projection = Linear(self.x_size + self.y_size, self.num_hidden)
#         self.linear = nn.Linear(self.num_hidden, 2)
#         self.l = nn.Linear(self.num_hidden, self.num_hidden)
#         self.softplus = nn.Softplus()
#
#         self.self_attentions = nn.ModuleList([Attention(num_hidden) for _ in range(2)])
#
#     def forward(self, x, y, target_x):
#         _, nt, x_size = target_x.shape  # (bs,nt, x_size)
#
#         encoder_input = torch.cat([x, y], dim=-1)  # concat context location (x), context value (y)
#         encoder_input = self.input_projection(encoder_input)  # (bs,nc,13)--> (bs,nc,num_hidden)
#         # encoder_input = self.l(encoder_input)
#
#         for attention in self.self_attentions:
#             encoder_input, _ = attention(encoder_input, encoder_input, encoder_input)
#
#         encoder = torch.mean(encoder_input, dim=1)  # (bs, 1,num_hidden)
#         encoder = encoder.unsqueeze(dim=1).repeat((1, nt, 1))  # (bs, num_hidden)
#         out = self.linear(encoder)  # decoder cat(z,target_x, r, w)  (bs,3*num_hidden+tx)--> (bs  nt, 2)
#         mu = out[:, :, 0]  # mean
#         log_sigma = out[:, :, 1]
#         sigma = 0.1 + 0.9 * self.softplus(log_sigma)  # variance  sigma=0.1+0.9*log(1+exp(log_sigma))
#         std = sigma.sqrt().cuda(0)
#         eps = torch.FloatTensor(std.size()).normal_().cuda(0)  # 随机张量方法normal_()，完成高斯空间的采样过程。
#         prior_sample = eps.mul(std).add_(mu)
#         return mu, sigma, prior_sample


class Decoder(nn.Module):
    """
    Dencoder
    """

    def __init__(self, x_size, y_size, num_hidden):
        super(Decoder, self).__init__()
        # self.x_size = x_size
        self.x_size = x_size
        self.y_size = y_size
        self.num_hidden = num_hidden
        self.attribute = Linear(self.x_size, int(self.num_hidden / 4))
        self.location = Linear(self.x_size, int(self.num_hidden / 4))
        self.l = Linear(1, int(self.num_hidden / 4))
        # self.decoder = nn.Sequential(
        #     nn.Linear(self.x_size + 1, num_hidden),
        #     nn.ReLU(),
        #     nn.Linear(num_hidden, 64),
        #     nn.ReLU(),
        #     nn.Dropout(0.05),
        #     nn.Linear(64, 2),
        # )
        self.decoder = nn.Sequential(
            nn.Linear(self.x_size + 1, num_hidden),
            nn.Dropout(0.3),
            nn.ReLU(),
            nn.Linear(num_hidden, 2),

        )
        self.softplus = nn.Softplus()

    def forward(self, target_x, w):
        """ context_x : (batch_size, n_context, x_size)
            context_y : (batch_size, n_context, y_size)
            target_x : (batch_size, n_target, x_size)
        """

        bs, nt, x_size = target_x.shape  # (bs,nt, x_size)

        z_tx = torch.cat([w.unsqueeze(-1), target_x], dim=-1)

        # s_x=self.location(target_x)
        # prior=prior.unsqueeze(-1)
        # t=self.l(prior)
        # z_tx=torch.cat([t,s_x], dim=-1)
        # # z_tx = torch.cat([torch.cat([z, z_tx], dim=-1),r], dim=-1)  # (bs, nt, z_size + x_size + z_size)
        # z_tx = torch.cat([z_tx,w], dim=-1)
        z_tx = z_tx.view((bs * nt, self.x_size + 1))
        decoder = self.decoder(z_tx)  # (bs * nt, 2)
        decoder = decoder.view((bs, nt, 2))  # (bs, nt, 2)
        mu = decoder[:, :, 0]
        log_sigma = decoder[:, :, 1]
        sigma = 0.1 + 0.9 * self.softplus(log_sigma)  # variance  sigma=0.1+0.9*log(1+exp(log_sigma))
        return mu, sigma


class SpatialNeuralProcess(nn.Module):
    def __init__(self, x_size, y_size, num_hidden):
        super(SpatialNeuralProcess, self).__init__()
        # self.training=training
        self.x_size = x_size
        self.y_size = y_size
        self.num_hidden = num_hidden
        self.determine = DeterministicEncoder(self.x_size + self.y_size, self.num_hidden)
        # self.location = LocationEncoder(num_hidden)
        # self.LatentEncoder = LatentEncoder(self.x_size, self.y_size, self.num_hidden)
        self.decoder = Decoder(self.x_size, self.y_size, self.num_hidden)

    def forward(self, context_x, context_y, target_x, target_y):
        """ context_x : (batch_size, n_context, x_size)
            context_y : (batch_size, n_context, y_size)
            target_x : (batch_size, n_target, x_size)
        """
        # if self.training:
        # _, _, q_context = self.LatentEncoder(context_x, context_y, target_x)  # Encoder  (context_x,ccontext_y)
        # _, _, q_target = self.LatentEncoder(target_x, target_y, target_x)
        r_mu, r_sigma, r_sample = self.determine(context_x, context_y, target_x)
        mu, sigma = self.decoder(target_x,r_sample)
        # std = sigma.sqrt().cuda(0)
        # eps = torch.FloatTensor(std.size()).normal_().cuda(0)  # 随机张量方法normal_()，完成高斯空间的采样过程。
        # y_pred = eps.mul(std).add_(mu)
        return mu, sigma
        # else:
        #     _, _, q_context = self.LatentEncoder(context_x, context_y, target_x)
        #     r_mu, r_sigma, r_sample = self.determine(context_x, context_y, target_x)
        #     mu, sigma = self.decoder(r_sample, target_x, q_context)
        #     # std = sigma.sqrt().cuda(0)
        #     # eps = torch.FloatTensor(std.size()).normal_().cuda(0)  # 随机张量方法normal_()，完成高斯空间的采样过程。
        #     # y_pred = eps.mul(std).add_(mu)
        #     return q_context, mu, sigma

class Criterion(nn.Module):
    def __init__(self):
        super(Criterion, self).__init__()

        self.kl_div = nn.KLDivLoss()
    def forward(self,mu, sigma,target_y=None):
        """ mu : (bs, n_target)
            sigma : (bs, n_target)
            target_y : (bs, n_target)
        """
        loss = 0.0
        bs = mu.shape[0]
        nt = mu.shape[1]
        target_y=target_y.squeeze(-1)
        if target_y is not None:
            for i in range(bs):
                dist1 = torch.distributions.multivariate_normal.MultivariateNormal(loc=mu[i],
                                                                                   covariance_matrix=torch.diag(sigma[i]))
                #
                # dist2=torch.distributions.multivariate_normal.MultivariateNormal(loc=prior_mu[i],
                #                                                                   covariance_matrix=torch.diag(
                #                                                                       prior_sigma[i]))
                # poster=dist1.sample().unsqueeze(0)
                # prior=dist2.sample().unsqueeze(0)
                # log_prob = dist1.log_prob(target_y.squeeze(-1)).mean(dim=0).sum()

                log_prob = dist1.log_prob(target_y[i])
                loss = -log_prob/nt  # torch.mean(log_prob)
        else:
            log_p = None
            loss = None

        loss = loss / bs

        return loss
